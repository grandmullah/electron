export interface Odds {
      decimal: number;
      american: number;
      multiplier: number;
}

export interface BetSelection {
      gameId: string;
      homeTeam: string;
      awayTeam: string;
      marketType: string;
      outcome: string;
      odds: Odds;
      bookmaker?: string;
      gameTime: string;
      sportKey: string;
}

export interface BetSlip {
      id: string;
      userId: string;
      selections: BetSelection[];
      stake: number;
      potentialWinnings: number;
      taxPercentage?: number;
      taxAmount?: number;
      netWinnings?: number;
      odds: Odds;
      createdAt: string;
      expiresAt: string;
}

export interface Bet extends Omit<BetSlip, 'expiresAt'> {
      status: 'pending' | 'accepted' | 'won' | 'lost' | 'cancelled' | 'void';
      updatedAt: string;
      settledAt?: string;
}
