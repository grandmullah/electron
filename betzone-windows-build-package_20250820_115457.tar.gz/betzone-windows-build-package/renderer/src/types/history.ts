export interface DisplayBetSelection {
      gameId: string;
      homeTeam: string;
      awayTeam: string;
      betType: string;
      selection: string;
      odds: number;
      stake: number;
      potentialWinnings: number;
      result: string;
}

export interface DisplayBet {
      id: string;
      betType: "single" | "multibet";
      totalStake: number;
      potentialWinnings: number;
      actualWinnings: number;
      createdAt: string;
      settledAt?: string;
      status: string;
      selections: DisplayBetSelection[];
      taxPercentage?: number;
      taxAmount?: number;
      netWinnings?: number;
      // optional odds field might exist in API mapping
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      [key: string]: any;
}


